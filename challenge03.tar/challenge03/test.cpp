// Challenge 06: Palindrome Permutation
#include <stdio.h>
#include <ctype.h>
#include <iostream>
#include <set>
#include <sstream>

using namespace std; 

int main(int argc, char *argv[]) {
	
	
	for(int i =0; i < 1000000; i++){
		cout<<" "<<i<<i<<i<<i<<i<<i<<i<<i<<endl;	
	}
	return (0);
}

